from django.contrib import admin
from list.models import Tasks
admin.site.register(Tasks)
# Register your models here.
